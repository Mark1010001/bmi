from components.sidebar import render_sidebar
from components.calculator import render_calculator
from components.dashboard import render_dashboard
from components.charts import (
    plot_bmi_histogram_plotly,
    plot_bai_histogram_plotly,
    plot_avg_bmi_by_age_plotly,
    plot_age_bmi_scatter_plotly,
    plot_risk_disparity_plotly,
)
