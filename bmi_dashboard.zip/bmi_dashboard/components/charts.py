"""
components/charts.py
═════════════════════
KDD Step 5 — Visualization

All Plotly chart-building functions:
  • plot_bmi_histogram_plotly      — BMI distribution with threshold lines
  • plot_bai_histogram_plotly      — BAI distribution with gender normal band
  • plot_avg_bmi_by_age_plotly     — Bar chart of average BMI per age group
  • plot_age_bmi_scatter_plotly    — Scatter + linear regression trend
  • plot_risk_disparity_plotly     — Risk reclassification by race/ethnicity
"""

import numpy as np
import plotly.graph_objects as go
import pandas as pd

from config.constants import CATEGORY_COLORS, BAI_CATEGORIES, PLOTLY_DARK
from models.classifier import classify_bmi, classify_bai


# ─────────────────────────────────────────────
# BMI HISTOGRAM
# ─────────────────────────────────────────────

def plot_bmi_histogram_plotly(df: pd.DataFrame, user_bmi: float = None) -> go.Figure:
    """Histogram of BMI values coloured by WHO category, with optional user marker."""
    fig  = go.Figure()
    bins = np.arange(12, 48, 2)
    counts, edges = np.histogram(df["BMI"], bins=bins)

    for left, right, count in zip(edges[:-1], edges[1:], counts):
        center = (left + right) / 2
        cat    = classify_bmi(center)
        fig.add_trace(go.Bar(
            x=[center], y=[count], width=1.8,
            marker_color=CATEGORY_COLORS[cat], marker_opacity=0.85,
            showlegend=False,
            hovertemplate=(
                f"BMI {left:.1f}-{right:.1f}<br>"
                f"Users: {count}<br>Category: {cat}<extra></extra>"
            ),
        ))

    for thresh, label in [(18.5, "18.5"), (25, "25"), (30, "30")]:
        fig.add_vline(
            x=thresh, line_dash="dot", line_color="#666", line_width=1,
            annotation_text=label, annotation_font_size=9,
            annotation_font_color="#888", annotation_position="top",
        )

    if user_bmi is not None:
        fig.add_vline(
            x=user_bmi, line_color="white", line_width=2, line_dash="dash",
            annotation_text=f"Your BMI: {user_bmi}",
            annotation_font_color="white", annotation_font_size=11,
            annotation_position="top right",
        )

    fig.update_layout(
        title=dict(text="BMI Distribution — 50 Users", font=dict(size=14, color="white")),
        xaxis_title="BMI", yaxis_title="Number of Users",
        barmode="overlay", showlegend=False, height=340,
        margin=dict(l=40, r=20, t=50, b=40), **PLOTLY_DARK,
    )
    return fig


# ─────────────────────────────────────────────
# BAI HISTOGRAM
# ─────────────────────────────────────────────

def plot_bai_histogram_plotly(
    df: pd.DataFrame,
    user_bai: float = None,
    gender: str = "Male",
) -> go.Figure:
    """BAI distribution chart with gender-specific normal range shading."""
    fig  = go.Figure()
    bins = np.arange(5, 60, 3)
    counts, edges = np.histogram(df["BAI"], bins=bins)

    for left, right, count in zip(edges[:-1], edges[1:], counts):
        center = (left + right) / 2
        cat    = classify_bai(center, "Male")          # male baseline for population colouring
        fig.add_trace(go.Bar(
            x=[center], y=[count], width=2.8,
            marker_color=CATEGORY_COLORS[cat], marker_opacity=0.82,
            showlegend=False,
            hovertemplate=(
                f"BAI {left:.1f}-{right:.1f}<br>"
                f"Users: {count}<br>Category: {cat}<extra></extra>"
            ),
        ))

    normal_low  = BAI_CATEGORIES[gender]["Normal"][0]
    normal_high = BAI_CATEGORIES[gender]["Normal"][1]
    fig.add_vrect(
        x0=normal_low, x1=normal_high,
        fillcolor="#639922", opacity=0.08,
        annotation_text=f"Normal ({gender})", annotation_position="top left",
        annotation_font_color="#639922", annotation_font_size=10,
    )

    if user_bai is not None:
        fig.add_vline(
            x=user_bai, line_color="white", line_width=2, line_dash="dash",
            annotation_text=f"Your BAI: {user_bai}%",
            annotation_font_color="white", annotation_font_size=11,
            annotation_position="top right",
        )

    fig.update_layout(
        title=dict(
            text="BAI Distribution — 50 Users (Body Fat %)",
            font=dict(size=14, color="white"),
        ),
        xaxis_title="BAI (Body Fat %)", yaxis_title="Number of Users",
        barmode="overlay", showlegend=False, height=340,
        margin=dict(l=40, r=20, t=50, b=40), **PLOTLY_DARK,
    )
    return fig


# ─────────────────────────────────────────────
# AVERAGE BMI BY AGE GROUP
# ─────────────────────────────────────────────

def plot_avg_bmi_by_age_plotly(patterns: dict) -> go.Figure:
    """Bar chart of mean BMI per age group, coloured by risk category."""
    data   = patterns["avg_bmi_by_age"]
    groups = list(data.index.astype(str))
    values = list(data.values)
    colors = [CATEGORY_COLORS[classify_bmi(v)] for v in values]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=groups, y=values,
        marker_color=colors, marker_opacity=0.85,
        text=[str(v) for v in values], textposition="outside",
        textfont=dict(color="white", size=12),
        hovertemplate="Age Group: %{x}<br>Avg BMI: %{y}<extra></extra>",
    ))
    fig.add_hrect(
        y0=18.5, y1=25, fillcolor="#639922", opacity=0.07,
        annotation_text="Normal range", annotation_position="top left",
        annotation_font_color="#639922", annotation_font_size=10,
    )
    fig.update_layout(
        title=dict(text="Average BMI by Age Group", font=dict(size=14, color="white")),
        xaxis_title="Age Group", yaxis_title="Average BMI",
        yaxis_range=[0, max(values) + 5], height=340,
        margin=dict(l=40, r=20, t=50, b=40), **PLOTLY_DARK,
    )
    return fig


# ─────────────────────────────────────────────
# AGE vs BMI SCATTER + LINEAR REGRESSION
# ─────────────────────────────────────────────

def plot_age_bmi_scatter_plotly(
    df: pd.DataFrame,
    user_age: int = None,
    user_bmi: float = None,
) -> go.Figure:
    """Scatter plot of Age vs BMI, with colour-coded categories and regression line."""
    fig = go.Figure()

    for cat, color in CATEGORY_COLORS.items():
        mask   = df["Risk_Category"] == cat
        subset = df[mask]
        fig.add_trace(go.Scatter(
            x=subset["Age"], y=subset["BMI"],
            mode="markers", name=cat,
            marker=dict(
                color=color, size=8, opacity=0.75,
                line=dict(width=0.5, color="#0e1117"),
            ),
            hovertemplate=f"<b>{cat}</b><br>Age: %{{x}}<br>BMI: %{{y}}<extra></extra>",
        ))

    coeffs  = np.polyfit(df["Age"].values, df["BMI"].values, 1)
    poly_fn = np.poly1d(coeffs)
    x_range = np.linspace(18, 70, 100)
    fig.add_trace(go.Scatter(
        x=x_range, y=poly_fn(x_range),
        mode="lines",
        name=f"Trend (slope={coeffs[0]:.3f})",
        line=dict(color="#a78bfa", width=2, dash="dash"),
        hovertemplate="Predicted BMI: %{y:.1f}<br>Age: %{x:.0f}<extra></extra>",
    ))

    if user_age and user_bmi:
        fig.add_trace(go.Scatter(
            x=[user_age], y=[user_bmi],
            mode="markers", name="You",
            marker=dict(
                color="white", size=14, symbol="star",
                line=dict(color="#a78bfa", width=2),
            ),
            hovertemplate=f"<b>You</b><br>Age: {user_age}<br>BMI: {user_bmi}<extra></extra>",
        ))

    fig.update_layout(
        title=dict(
            text="Age vs BMI — Scatter + Regression Trend",
            font=dict(size=14, color="white"),
        ),
        xaxis_title="Age", yaxis_title="BMI",
        legend=dict(bgcolor="#1c1c2e", bordercolor="#333", font=dict(color="#ccc")),
        height=360, margin=dict(l=40, r=20, t=50, b=40), **PLOTLY_DARK,
    )
    return fig


# ─────────────────────────────────────────────
# RISK DISPARITY BY RACE
# ─────────────────────────────────────────────

def plot_risk_disparity_plotly(patterns: dict) -> go.Figure:
    """Bar chart of users reclassified from Normal → High Risk by ethnic thresholds."""
    disparity_by_race = patterns["disparity_by_race"]
    races  = disparity_by_race["Race"].tolist()
    counts = disparity_by_race["Reclassified_Count"].tolist()

    race_colors = {
        "White/Other": "#7ec8e3",
        "Asian":       "#f4a261",
        "Black":       "#a29bfe",
    }
    colors = [race_colors.get(r, "#aaa") for r in races]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        x=races, y=counts,
        marker_color=colors, marker_opacity=0.88,
        text=counts, textposition="outside",
        textfont=dict(color="white", size=13),
        hovertemplate="Race: %{x}<br>Reclassified users: %{y}<extra></extra>",
    ))
    fig.update_layout(
        title=dict(
            text="Risk Disparity: Normal → High Risk Under Ethnic Thresholds",
            font=dict(size=13, color="white"),
        ),
        xaxis_title="Race / Ethnicity",
        yaxis_title="Users Reclassified",
        yaxis_range=[0, max(counts) + 3 if counts else 5],
        height=340, margin=dict(l=40, r=20, t=60, b=40), **PLOTLY_DARK,
    )
    return fig
