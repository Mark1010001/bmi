"""
components/calculator.py
═════════════════════════
Left panel of the dashboard:
  • Gender / Age / Weight / Height / Hip inputs
  • BMI + BAI dual metric cards (with agreement indicator)
  • Comparison table (WHO vs Asian standard)
  • Educational expander
  • Risk probability banner
  • Population benchmark card
  • Health advice (nutrition, activity, medical note)
"""

import streamlit as st
import pandas as pd

from config.constants import (
    CATEGORY_COLORS,
    STANDARD_THRESHOLDS,
    ASIAN_THRESHOLDS,
    RISK_PROBABILITY,
    BAI_CATEGORIES,
    STANDARD_GLOBAL,
    STANDARD_ASIAN,
)
from models.classifier import (
    calculate_bmi,
    calculate_bai,
    classify_bai,
    classify_with_thresholds,
    get_age_band,
)
from utils.advice import HEALTH_ADVICE


# ─────────────────────────────────────────────
# COMPARISON TABLE
# ─────────────────────────────────────────────

def render_comparison_table(bmi: float, active_standard: str) -> None:
    """Render a styled HTML table comparing WHO vs Asian classification for this BMI."""
    global_cat = classify_with_thresholds(bmi, STANDARD_THRESHOLDS)
    asian_cat  = classify_with_thresholds(bmi, ASIAN_THRESHOLDS)

    global_label = f"Global WHO{' (Active)' if active_standard == STANDARD_GLOBAL else ''}"
    asian_label  = f"Asian Clinical{' (Active)' if active_standard == STANDARD_ASIAN else ''}"

    rows_html = ""
    for label, cat, overweight_cut, obese_cut in [
        (global_label, global_cat, "BMI ≥ 25.0", "BMI ≥ 30.0"),
        (asian_label,  asian_cat,  "BMI ≥ 23.0", "BMI ≥ 27.5"),
    ]:
        cat_color  = CATEGORY_COLORS[cat]
        is_active  = "(Active)" in label
        row_bg     = "background:#1a1a30;" if is_active else "background:#13131f;"
        border_left = f"border-left: 3px solid {cat_color};" if is_active else ""
        rows_html += f"""
        <tr style="{row_bg}{border_left}">
          <td style="padding:10px 14px; color:{'white' if is_active else '#aaa'};
                     font-weight:{'600' if is_active else '400'};">{label}</td>
          <td style="padding:10px 14px; color:#ccc; text-align:center;">{overweight_cut}</td>
          <td style="padding:10px 14px; color:#ccc; text-align:center;">{obese_cut}</td>
          <td style="padding:10px 14px; text-align:center;">
            <span style="background:{cat_color}22; color:{cat_color}; border:1px solid {cat_color};
                         border-radius:6px; padding:3px 10px; font-weight:600; font-size:13px;">
              {cat}
            </span>
          </td>
        </tr>"""

    st.markdown(f"""
    <div style="margin:14px 0;">
      <p style="font-size:12px; color:#888; text-transform:uppercase; letter-spacing:0.05em;
                margin-bottom:8px;">Your BMI {bmi} — Standard Comparison</p>
      <table style="width:100%; border-collapse:collapse; border-radius:10px; overflow:hidden;
                    border:1px solid #2a2a3e;">
        <thead>
          <tr style="background:#0d0d1f;">
            <th style="padding:10px 14px; color:#666; text-align:left; font-size:11px;
                       text-transform:uppercase;">Standard</th>
            <th style="padding:10px 14px; color:#666; text-align:center; font-size:11px;
                       text-transform:uppercase;">Overweight Cutoff</th>
            <th style="padding:10px 14px; color:#666; text-align:center; font-size:11px;
                       text-transform:uppercase;">Obese Cutoff</th>
            <th style="padding:10px 14px; color:#666; text-align:center; font-size:11px;
                       text-transform:uppercase;">Your Category</th>
          </tr>
        </thead>
        <tbody>{rows_html}</tbody>
      </table>
    </div>
    """, unsafe_allow_html=True)


# ─────────────────────────────────────────────
# EDUCATIONAL EXPANDER
# ─────────────────────────────────────────────

def render_educational_expander() -> None:
    """Collapsible section explaining the two BMI standards and why BMI+BAI is better."""
    with st.expander("Why are there two BMI standards?"):
        st.markdown("""
        ### The Two BMI Standards Explained

        **Global WHO Standard** (established 1995, revised 2000)
        - Developed using data primarily from European populations
        - Overweight: BMI ≥ 25.0 | Obese: BMI ≥ 30.0

        **Asian Clinical Standard** (2026 cardiometabolic guidelines)
        - Asian individuals carry more visceral fat at the same BMI value
        - Metabolic disease appears at BMI as low as 22-23 in Asian populations
        - Overweight threshold: **BMI ≥ 23.0** | Obese: **BMI ≥ 27.5**

        **Why BMI + BAI together is better**
        BMI only uses height and weight — it cannot distinguish muscle from fat.
        BAI (Body Adiposity Index) uses **hip circumference** which directly
        reflects fat distribution, especially around the hips and thighs.
        Using both gives a much more complete picture of actual body composition.

        > *Sources: WHO Expert Consultation (2004, updated 2026); Bergman et al. (2011),
        > A Better Index of Body Adiposity, Obesity Journal.*
        """)


# ─────────────────────────────────────────────
# FULL LEFT PANEL
# ─────────────────────────────────────────────

def render_calculator(active_standard: str, patterns: dict) -> tuple:
    """
    Render the full left calculator panel and return computed user metrics.

    Returns:
        (gender, age, user_bmi, user_bai, user_bmi_cat, user_bai_cat)
    """
    st.subheader("Your BMI + BAI Calculator")

    # ── Inputs ──
    gender = st.radio(
        "Gender", options=["Male", "Female"], horizontal=True,
        help="Used to apply gender-specific BAI healthy range thresholds.",
    )
    age    = st.slider("Age",                 min_value=10,   max_value=100,  value=25)
    weight = st.slider("Weight (kg)",         min_value=30.0, max_value=200.0, value=70.0, step=0.5)
    height = st.slider("Height (cm)",         min_value=100,  max_value=220,  value=170)
    hip_cm = st.slider(
        "Hip Circumference (cm)",
        min_value=60, max_value=160,
        value=95 if gender == "Male" else 100,
        help="Measure around the widest part of your hips. Used to calculate BAI (body fat %).",
    )

    height_m     = height / 100
    active_thresholds = (
        STANDARD_THRESHOLDS if active_standard == STANDARD_GLOBAL else ASIAN_THRESHOLDS
    )

    # ── Compute metrics ──
    user_bmi     = calculate_bmi(weight, height_m)
    user_bai     = calculate_bai(hip_cm, height_m)
    user_bmi_cat = classify_with_thresholds(user_bmi, active_thresholds)
    user_bai_cat = classify_bai(user_bai, gender)
    bmi_color    = CATEGORY_COLORS[user_bmi_cat]
    bai_color    = CATEGORY_COLORS[user_bai_cat]
    advice       = HEALTH_ADVICE[user_bmi_cat]

    st.markdown("---")

    # ── Dual metric cards ──
    c1, c2 = st.columns(2)
    with c1:
        standard_color = "#639922" if active_standard == STANDARD_GLOBAL else "#f4a261"
        standard_short = "Global WHO" if active_standard == STANDARD_GLOBAL else "Asian 2026"
        st.markdown(f"""
        <div class="metric-card" style="border-color:{bmi_color};">
          <p class="metric-label">BMI</p>
          <p class="metric-value" style="color:{bmi_color};">{user_bmi}</p>
          <p style="margin:4px 0 0; font-size:14px; color:#ccc;">
            {HEALTH_ADVICE[user_bmi_cat]['emoji']} {user_bmi_cat}
          </p>
          <p style="margin:3px 0 0; font-size:11px; color:{standard_color};">{standard_short}</p>
        </div>
        """, unsafe_allow_html=True)
    with c2:
        st.markdown(f"""
        <div class="metric-card" style="border-color:{bai_color};">
          <p class="metric-label">BAI (Body Fat %)</p>
          <p class="metric-value" style="color:{bai_color};">{user_bai}%</p>
          <p style="margin:4px 0 0; font-size:14px; color:#ccc;">
            {HEALTH_ADVICE[user_bai_cat]['emoji']} {user_bai_cat}
          </p>
          <p style="margin:3px 0 0; font-size:11px; color:#a78bfa;">{gender} standard</p>
        </div>
        """, unsafe_allow_html=True)

    # ── Agreement indicator ──
    if user_bmi_cat == user_bai_cat:
        st.markdown(f"""
        <div class="agree-badge" style="background:rgba(99,153,34,0.12);
             border:1px solid #639922; color:#639922;">
          ✅ <b>BMI and BAI agree</b> — both classify you as <b>{user_bmi_cat}</b>.
          This increases confidence in the result.
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="agree-badge" style="background:rgba(186,117,23,0.12);
             border:1px solid #BA7517; color:#BA7517;">
          ⚠️ <b>BMI and BAI disagree.</b> BMI says <b>{user_bmi_cat}</b>,
          BAI says <b>{user_bai_cat}</b>.
          BAI may better reflect actual body fat — consult your doctor.
        </div>
        """, unsafe_allow_html=True)

    # ── Comparison table + educational expander ──
    render_comparison_table(user_bmi, active_standard)
    render_educational_expander()
    st.markdown("---")

    # ── Risk Probability ──
    age_band  = get_age_band(age)
    risk_key  = (age_band, user_bmi_cat)
    risk_data = RISK_PROBABILITY.get(risk_key, {"prob": 0.10, "level": "Low", "color": "#639922"})
    prob_pct  = int(risk_data["prob"] * 100)
    risk_lvl  = risk_data["level"]
    risk_col  = risk_data["color"]

    if age_band == "Senior" and user_bmi_cat == "Obese":
        st.markdown(f"""
        <div class="risk-banner" style="background:rgba(226,75,74,0.15); border:2px solid #E24B4A;">
          <strong style="color:#E24B4A; font-size:15px;">HIGH-PRIORITY CLINICAL ALERT</strong><br>
          <span style="color:#eee;">Individuals aged <b>60+</b> with Obese BMI face an estimated
          <b style="color:#FF6B6B;">{prob_pct}% complication rate</b>
          (2026 clinical benchmarks).</span><br>
          <span style="color:#ffaaaa; font-size:13px;">
            Immediate medical consultation strongly recommended.
          </span>
        </div>
        """, unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="risk-banner" style="background:rgba(255,255,255,0.04); border:1px solid #2a2a3e;">
          <strong style="color:{risk_col};">Risk Probability: {risk_lvl}</strong><br>
          <span style="color:#ccc; font-size:13px;">
            Estimated complication risk for <b>{age_band}</b> / <b>{user_bmi_cat}</b>:
            <b style="color:{risk_col};">{prob_pct}%</b> (2026 benchmarks)
          </span>
        </div>
        """, unsafe_allow_html=True)

    # ── Population Benchmark ──
    dataset_avg = patterns["overall_avg_bmi"]
    diff        = round(user_bmi - dataset_avg, 1)
    diff_pct    = round(abs(diff) / dataset_avg * 100, 1)

    if diff < 0:
        bench_msg   = f"You are <b style='color:#639922;'>{diff_pct}% healthier</b> than the dataset average"
        bench_sub   = f"Your BMI ({user_bmi}) is {abs(diff)} below the avg ({dataset_avg})"
        bench_color = "#639922"
    elif diff == 0:
        bench_msg   = f"Your BMI exactly matches the dataset average ({dataset_avg})"
        bench_sub   = "You're right at the population mean"
        bench_color = "#aaa"
    else:
        bench_msg   = f"Your BMI is <b style='color:#BA7517;'>{diff_pct}% above</b> the dataset average"
        bench_sub   = f"Your BMI ({user_bmi}) is {diff} above the avg ({dataset_avg})"
        bench_color = "#BA7517"

    st.markdown(f"""
    <div class="benchmark-card" style="border-color:{bench_color};">
      <p class="metric-label">Population Benchmark</p>
      <p style="font-size:15px; color:#eee; margin:8px 0 4px;">{bench_msg}</p>
      <p style="font-size:12px; color:#888; margin:0;">{bench_sub}</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Health Advice ──
    st.markdown(f"> {advice['summary']}")
    st.markdown('<p class="section-title">Nutrition</p>', unsafe_allow_html=True)
    for tip in advice["nutrition"]:
        st.markdown(f"- {tip}")
    st.markdown('<p class="section-title">Activity</p>', unsafe_allow_html=True)
    for tip in advice["activity"]:
        st.markdown(f"- {tip}")
    st.markdown(f"""
    <div class="advice-card" style="border-color:{bmi_color};">
      <p class="section-title" style="margin:0 0 4px;">Medical Note</p>
      <p style="margin:0; color:#ccc; font-size:14px;">{advice['medical']}</p>
    </div>
    """, unsafe_allow_html=True)

    return gender, age, user_bmi, user_bai, user_bmi_cat, user_bai_cat
