"""
components/dashboard.py
════════════════════════
Right panel of the dashboard — Population Patterns:
  • KPI metric cards (Users, Avg BMI, Avg BAI, Std Dev, Agreement %)
  • Risk category breakdown bar
  • Risk disparity insight banner
  • 5-tab chart panel (BMI dist, BAI dist, Avg by age, Scatter, Disparity)
  • Sample dataset expander
"""

import numpy as np
import streamlit as st

from config.constants import CATEGORY_COLORS, BAI_CATEGORIES
from components.charts import (
    plot_bmi_histogram_plotly,
    plot_bai_histogram_plotly,
    plot_avg_bmi_by_age_plotly,
    plot_age_bmi_scatter_plotly,
    plot_risk_disparity_plotly,
)


def render_dashboard(
    df,
    patterns: dict,
    user_bmi: float,
    user_bai: float,
    user_age: int,
    gender: str,
) -> None:
    """Render the full right-side population analytics dashboard."""
    st.subheader("Population Patterns Dashboard")

    # ── KPI Cards ──
    m1, m2, m3, m4, m5 = st.columns(5)
    with m1:
        st.markdown(f"""<div class="metric-card">
          <p class="metric-label">Users</p>
          <p class="metric-value">{patterns['total_users']}</p></div>""",
          unsafe_allow_html=True)
    with m2:
        st.markdown(f"""<div class="metric-card">
          <p class="metric-label">Avg BMI</p>
          <p class="metric-value">{patterns['overall_avg_bmi']}</p></div>""",
          unsafe_allow_html=True)
    with m3:
        st.markdown(f"""<div class="metric-card">
          <p class="metric-label">Avg BAI</p>
          <p class="metric-value" style="color:#a78bfa;">{patterns['overall_avg_bai']}%</p>
          </div>""", unsafe_allow_html=True)
    with m4:
        st.markdown(f"""<div class="metric-card">
          <p class="metric-label">Std Dev</p>
          <p class="metric-value">{patterns['bmi_std']}</p></div>""",
          unsafe_allow_html=True)
    with m5:
        agree     = patterns['agreement_count']
        agree_pct = round(agree / patterns['total_users'] * 100)
        st.markdown(f"""<div class="metric-card">
          <p class="metric-label">BMI=BAI Agree</p>
          <p class="metric-value" style="font-size:20px;color:#639922;">{agree_pct}%</p>
          </div>""", unsafe_allow_html=True)

    st.markdown("")

    # ── Category Breakdown ──
    cats   = ["Underweight", "Normal", "Overweight", "Obese"]
    counts = [patterns["category_counts"].get(c, 0) for c in cats]
    total  = sum(counts)

    st.markdown(
        '<p class="section-title">Risk category breakdown (BMI standard)</p>',
        unsafe_allow_html=True,
    )
    cols = st.columns(len(cats))
    for col, cat, count in zip(cols, cats, counts):
        pct = round(count / total * 100)
        col.markdown(f"""
        <div style="text-align:center;">
          <div style="height:6px; background:{CATEGORY_COLORS[cat]}; border-radius:4px;
                      width:{pct}%; margin:0 auto 4px;"></div>
          <p style="font-size:11px; color:#888; margin:0;">{cat}</p>
          <p style="font-size:18px; font-weight:600; margin:0;
                    color:{CATEGORY_COLORS[cat]};">{count}</p>
          <p style="font-size:11px; color:#666; margin:0;">{pct}%</p>
        </div>""", unsafe_allow_html=True)

    st.markdown("")

    # ── Disparity Insight Banner ──
    disp_count = patterns["disparity_count"]
    st.markdown(f"""
    <div class="disparity-banner">
      <b style="color:#a29bfe;">Risk Disparity Insight:</b>
      &nbsp;<b style="color:white;">{disp_count} out of {patterns['total_users']} users</b>
      are classified as <b>'Normal'</b> under WHO standard but
      <b>'High Risk'</b> under ethnic-adjusted thresholds.
      &nbsp;|&nbsp;
      <b style="color:#639922;">{patterns['agreement_count']} users</b>
      get the same category from both BMI and BAI.
    </div>
    """, unsafe_allow_html=True)

    # ── Chart Tabs ──
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "BMI Distribution",
        "BAI Distribution",
        "Avg BMI by Age",
        "Age vs BMI + Trend",
        "Risk Disparity",
    ])

    with tab1:
        st.plotly_chart(
            plot_bmi_histogram_plotly(df, user_bmi=user_bmi),
            use_container_width=True,
        )
    with tab2:
        st.plotly_chart(
            plot_bai_histogram_plotly(df, user_bai=user_bai, gender=gender),
            use_container_width=True,
        )
        st.caption(
            f"Normal BAI range for {gender}: "
            f"{BAI_CATEGORIES[gender]['Normal'][0]}% – "
            f"{BAI_CATEGORIES[gender]['Normal'][1]}% body fat "
            f"(Bergman et al., 2011)"
        )
    with tab3:
        st.plotly_chart(
            plot_avg_bmi_by_age_plotly(patterns),
            use_container_width=True,
        )
    with tab4:
        st.plotly_chart(
            plot_age_bmi_scatter_plotly(df, user_age=user_age, user_bmi=user_bmi),
            use_container_width=True,
        )
        coeffs = np.polyfit(df["Age"].values, df["BMI"].values, 1)
        st.caption(
            f"Regression: BMI = {coeffs[0]:.3f} × Age + {coeffs[1]:.2f} "
            f"(BMI rises ~{coeffs[0]:.2f} per year)"
        )
    with tab5:
        st.plotly_chart(
            plot_risk_disparity_plotly(patterns),
            use_container_width=True,
        )
        st.caption(
            "Users classified 'Normal' under WHO standard but 'Overweight/Obese' "
            "under their ethnic-adjusted threshold."
        )
        if not patterns["disparity_df"].empty:
            with st.expander("View reclassified users"):
                disp_cols = [
                    "Age", "Gender", "Race", "BMI", "BAI",
                    "Risk_Category", "BAI_Category", "Ethnic_Category",
                ]
                st.dataframe(
                    patterns["disparity_df"][disp_cols].reset_index(drop=True),
                    use_container_width=True,
                )

    # ── Sample Dataset ──
    with st.expander("View Sample Dataset (first 15 rows)"):
        display_cols = [
            "Age", "Gender", "Race", "Height_m", "Weight_kg", "Hip_cm",
            "BMI", "BAI", "Risk_Category", "BAI_Category", "Age_Group",
        ]
        st.dataframe(df[display_cols].head(15), use_container_width=True)
