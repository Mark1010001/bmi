"""
components/sidebar.py
══════════════════════
Renders the Streamlit sidebar:
  • BMI standard radio toggle (Global WHO / Asian Clinical)
  • Threshold info card (updates with selection)
  • BAI healthy ranges reference card
  • App version caption
"""

import streamlit as st

from config.constants import STANDARD_GLOBAL, STANDARD_ASIAN


def render_sidebar() -> tuple[str, str]:
    """
    Render the left sidebar and return the selected standard and mapped ethnicity.

    Returns:
        active_standard (str): STANDARD_GLOBAL or STANDARD_ASIAN
        ethnicity (str):       "White/Other" or "Asian" (used for ethnic classification)
    """
    with st.sidebar:
        st.header("User Settings")
        st.markdown("---")

        st.markdown("**Select Your BMI Standard**")
        active_standard = st.radio(
            label="Select Standard",
            options=[STANDARD_GLOBAL, STANDARD_ASIAN],
            index=0,
            help=(
                "Global WHO: Overweight ≥ 25, Obese ≥ 30. "
                "Asian Clinical (2026): Overweight ≥ 23, Obese ≥ 27.5."
            ),
        )

        if active_standard == STANDARD_GLOBAL:
            st.markdown("""
            <div style="background:#1c1c2e; border:1px solid #2a2a3e; border-radius:8px;
                        padding:12px; margin-top:6px; font-size:13px; color:#ccc;">
              <b style="color:#639922;">Global WHO Thresholds</b><br>
              Normal &nbsp;&nbsp;&nbsp;&nbsp;: 18.5 – 24.9<br>
              Overweight : 25.0 – 29.9<br>
              Obese &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: ≥ 30.0<br><br>
              <span style="color:#666; font-size:12px;">Applies to: White / Other populations</span>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div style="background:#1c1c2e; border:1px solid #3a3a5e; border-radius:8px;
                        padding:12px; margin-top:6px; font-size:13px; color:#ccc;">
              <b style="color:#f4a261;">Asian Clinical Thresholds (2026)</b><br>
              Normal &nbsp;&nbsp;&nbsp;&nbsp;: 18.5 – 22.9<br>
              Overweight : 23.0 – 27.4<br>
              Obese &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: ≥ 27.5<br><br>
              <span style="color:#666; font-size:12px;">Applies to: Asian & Black populations</span>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("---")
        st.markdown("""
        <div style="background:#1c1c2e; border:1px solid #2a2a3e; border-radius:8px;
                    padding:12px; font-size:13px; color:#ccc;">
          <b style="color:#a78bfa;">BAI Healthy Ranges</b><br>
          <b>Male:</b> Normal = 8 – 21% body fat<br>
          <b>Female:</b> Normal = 21 – 33% body fat<br><br>
          <span style="color:#666; font-size:12px;">Source: Bergman et al. (2011)</span>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("---")
        st.caption("v5 · KDD Pipeline · BMI + BAI · WHO + 2026 Clinical Standards")

    ethnicity = "Asian" if active_standard == STANDARD_ASIAN else "White/Other"
    return active_standard, ethnicity
