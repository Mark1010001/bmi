"""
app.py — BMI Health Risk Classifier & Data Mining Dashboard
════════════════════════════════════════════════════════════
Entry point. Run with:  streamlit run app.py

KDD Pipeline:
  Step 1  Data Collection    →  data/generator.py :: generate_dataset()
  Step 2  Data Cleaning      →  data/generator.py :: generate_dataset()  (clipping)
  Step 3  Transformation     →  data/generator.py :: transform_dataset()
  Step 4  Data Mining        →  data/generator.py :: mine_patterns()
  Step 5  Visualization      →  components/charts.py + components/dashboard.py

Architecture:
  config/     — constants, thresholds, color maps
  models/     — BMI / BAI calculation & classification logic
  data/       — synthetic dataset generation, transformation, mining
  utils/      — health advice content
  components/ — Streamlit UI panels (sidebar, calculator, dashboard, charts)
"""

import streamlit as st

from data.generator import generate_dataset, transform_dataset, mine_patterns
from components.sidebar import render_sidebar
from components.calculator import render_calculator
from components.dashboard import render_dashboard


# ─────────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────────

st.set_page_config(
    page_title="BMI Health Risk Classifier",
    page_icon="🏥",
    layout="wide",
)


# ─────────────────────────────────────────────
# GLOBAL CSS
# ─────────────────────────────────────────────

st.markdown("""
<style>
  .metric-card {
    background: #1c1c2e; border: 1px solid #2a2a3e;
    border-radius: 12px; padding: 14px 18px;
    text-align: center; margin-bottom: 8px;
  }
  .metric-label {
    font-size: 12px; color: #888; margin: 0;
    text-transform: uppercase; letter-spacing: 0.05em;
  }
  .metric-value { font-size: 26px; font-weight: 600; margin: 4px 0 0; color: #fff; }
  .advice-card {
    background: #1c1c2e; border-left: 4px solid;
    border-radius: 8px; padding: 14px 16px; margin-bottom: 10px;
  }
  .section-title {
    font-size: 13px; font-weight: 600; color: #aaa;
    text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 8px;
  }
  .risk-banner {
    border-radius: 10px; padding: 16px 20px; margin: 12px 0;
    font-size: 14px; line-height: 1.6;
  }
  .benchmark-card {
    background: #1c1c2e; border: 1px solid #2a2a3e;
    border-radius: 12px; padding: 16px 20px; margin: 10px 0; text-align: center;
  }
  .disparity-banner {
    background: rgba(162,155,254,0.10); border: 1px solid #a29bfe;
    border-radius: 10px; padding: 14px 18px; margin: 10px 0; font-size: 14px;
  }
  .agree-badge {
    border-radius: 8px; padding: 10px 14px; margin: 10px 0;
    font-size: 13px; text-align: center;
  }
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
# HEADER
# ─────────────────────────────────────────────

st.title("🏥 BMI Health Risk Classifier")
st.caption(
    "KDD-powered health dashboard · v5 · BMI + BAI dual-metric · "
    "WHO standards · Ethnic-specific thresholds · Interactive charts"
)
st.divider()


# ─────────────────────────────────────────────
# DATA PIPELINE  (Steps 1–4)
# ─────────────────────────────────────────────

raw_df   = generate_dataset(50)
df       = transform_dataset(raw_df)
patterns = mine_patterns(df)


# ─────────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────────

active_standard, ethnicity = render_sidebar()


# ─────────────────────────────────────────────
# TWO-COLUMN LAYOUT
# ─────────────────────────────────────────────

left, right = st.columns([1, 1.6], gap="large")

with left:
    gender, age, user_bmi, user_bai, user_bmi_cat, user_bai_cat = render_calculator(
        active_standard=active_standard,
        patterns=patterns,
    )

with right:
    render_dashboard(
        df=df,
        patterns=patterns,
        user_bmi=user_bmi,
        user_bai=user_bai,
        user_age=age,
        gender=gender,
    )


# ─────────────────────────────────────────────
# FOOTER
# ─────────────────────────────────────────────

st.divider()
st.caption(
    "KDD Pipeline: Step 1 Collection > Step 2 Cleaning > Step 3 Transformation > "
    "Step 4 Mining > Step 5 Visualization  |  "
    "WHO BMI Standards · Asian Clinical 2026 · Bergman BAI Formula"
)
st.markdown("""
<div style="background:#12122a; border:1px solid #2a2a3e; border-radius:10px;
            padding:16px 20px; margin-top:8px; font-size:13px; color:#999; line-height:1.7;">
  <b style="color:#a29bfe;">Clinical Disclaimer</b><br>
  BMI thresholds for Asian populations (Overweight ≥ 23.0, Obese ≥ 27.5) are based on
  <b>2025-2026 cardiometabolic risk studies</b> and WHO Expert Consultation guidelines.
  BAI (Body Adiposity Index) formula and gender-specific healthy ranges are based on
  <b>Bergman et al. (2011), Obesity Journal</b>. Both metrics are screening tools only
  and do not constitute medical advice. Always consult a qualified healthcare professional.
</div>
""", unsafe_allow_html=True)
